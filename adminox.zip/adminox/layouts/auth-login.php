<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8" />
    <title>Z-ERP | Connexion</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Z-ERP - Optimisez la gestion de vos ressources et améliorez l'efficacité de votre entreprise avec notre tableau de bord administrateur réactif." name="description" />
    <meta content="Coderthemes" name="author" />

    <!-- Icône de l'application -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- CSS du fournisseur -->
    <link href="assets/css/vendor.min.css" rel="stylesheet" type="text/css" />

    <!-- CSS de l'application -->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-style" />

    <!-- CSS des icônes -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />

    <!-- Configuration du thème -->
    <script src="assets/js/config.js"></script>
</head>

<body class="authentication-bg bg-primary authentication-bg-pattern d-flex align-items-center pb-0 vh-100">

    <div class="account-pages w-100 mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card mb-0">
                        <div class="card-body p-4">
                            <div class="account-box">
                                <div class="account-logo-box">
                                    <div class="text-center">
                                        <h1>Z-ERP</h1>
                                    </div>
                                    <h5 class="text-uppercase mb-1 mt-4 fw-semibold">Se Connecter</h5>
                                    <p class="mb-0">Connectez-vous à votre compte Administrateur</p>
                                </div>

                                <div class="account-content mt-4">
                                    <form class="form-horizontal" action="#">

                                        <div class="form-group row">
                                            <div class="col-12">
                                                <label for="emailaddress">Adresse e-mail</label>
                                                <input class="form-control" type="email" id="emailaddress" required="" placeholder="john@deo.com">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-12">
                                                <a href="page-recoverpw.html" class="text-muted float-end"><small>Mot de passe oublié ?</small></a>
                                                <label for="password">Mot de passe</label>
                                                <input class="form-control" type="password" required="" id="password" placeholder="Entrez votre mot de passe">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-12">
                                                <div class="checkbox form-checkbox-success">
                                                    <input id="remember" type="checkbox" checked="">
                                                    <label for="remember">
                                                        Se souvenir de moi
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group row text-center mt-2">
                                            <div class="col-12">
                                                <button class="btn btn-md btn-block btn-primary waves-effect waves-light w-100" type="submit">Se Connecter</button>
                                            </div>
                                        </div>

                                    </form>

                                    <div class="row mt-4 pt-2">
                                        <div class="col-sm-12 text-center">
                                            <p class="text-muted mb-0">Vous n'avez pas de compte? <a href="page-register.html" class="text-dark ms-1"><b>Inscrivez-vous</b></a></p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end card-body -->
                </div>
                <!-- end card -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->

    <!-- JS du fournisseur -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- JS de l'application -->
    <script src="assets/js/app.js"></script>

</body>
</html>
